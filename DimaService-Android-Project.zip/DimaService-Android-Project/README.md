# DimaService Android App

CRM per riparazioni - Versione Android con WebView

## 📋 Prerequisiti

- Android Studio 2022.1+
- Android SDK 21+
- Gradle 8.1+
- Java/Kotlin

## 🚀 Come Compilare l'APK

### 1. Apri il Progetto

```bash
Apri Android Studio
File → Open
Seleziona questa cartella (DimaService-Android-Project)
```

### 2. Sincronizza Gradle

```
Android Studio lo farà automaticamente
O manualmente: File → Sync Now
```

### 3. Compila l'APK Debug

```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

L'APK sarà generato in:
```
app/build/outputs/apk/debug/app-debug.apk
```

### 4. Installa su Dispositivo/Emulatore

```
Run → Run 'app'
O trasferisci app-debug.apk sul dispositivo e installa
```

## 📱 Caratteristiche

✅ Gestione clienti offline
✅ Upload allegati fino a 200MB  
✅ Fotocamera e galleria
✅ Export Excel / Backup JSON
✅ Tema light/dark automatico
✅ localStorage + IndexedDB

## 🔧 Struttura

```
DimaService-Android-Project/
├── app/
│   ├── src/main/
│   │   ├── kotlin/com/dimaservice/gestionepro/
│   │   │   └── MainActivity.kt
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── values/strings.xml
│   │   │   └── assets/index.html
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## 📝 Note

- L'app carica DimaService-COMPLETO.html come index.html
- Supporta upload file fino a 200MB
- Dati salvati in localStorage + IndexedDB
- Funziona offline completamente

Buona compilazione! 🚀
