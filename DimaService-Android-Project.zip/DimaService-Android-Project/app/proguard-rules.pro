# ProGuard rules for DimaService Android App

# Keep WebView
-keepclassmembers class * extends android.webkit.WebViewClient {
    public void *(android.webkit.WebView, java.lang.String);
}

-keepclassmembers class * extends android.webkit.WebChromeClient {
    public void onPermissionRequest(android.webkit.PermissionRequest);
}

# Keep JavaScript interfaces
-keepclasseswithmembernames class * {
    @android.webkit.JavascriptInterface <methods>;
}

# General Android
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver

# Preserve line numbers for better error reports
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Kotlin
-keep class kotlin.** { *; }
-keepclassmembers class kotlin.** { *; }

# Suppress warnings
-dontwarn kotlin.**
-dontwarn org.jetbrains.annotations.**
